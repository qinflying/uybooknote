# different-ways-of-shaking-camera-In-unity
The main objective of this blog post is to give you an idea about Camera Shake in Unity3D.
